# programmez-josdk-article
Code source pour l'article sur les opérateurs Java dans Kubernetes
